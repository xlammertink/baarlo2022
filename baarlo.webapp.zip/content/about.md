+++
title = "About"
slug = "about"
+++

[ Insert explaination of baarlo here ]

# What to bring

* There are beds for everyone, you don’t have to bring your sleeping bag or pillow to the venue. Also towels are provided.
* Breakfast, lunch and dinner will be provided at the venue.
* The dress code is casual, leave your suits and ties at home!
* Please take with you:
  * Your laptop as you might need it during training sessions
  * Sportswear, comfortable shoes, an extra towel and a water bottle
  * Your most creative “Hawaii” outfit!
  * Valid QR code + Deloitte badge (please make sure your QR code is valid for the whole event)
